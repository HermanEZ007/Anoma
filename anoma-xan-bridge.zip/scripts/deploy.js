const { ethers } = require('hardhat');

async function main() {
  const [deployer] = await ethers.getSigners();
  console.log('Deploying contracts with', deployer.address);

  const Mock = await ethers.getContractFactory('MockERC20');
  const mock = await Mock.deploy('Mock XAN', 'XAN', ethers.utils.parseUnits('1000000', 18));
  await mock.deployed();
  console.log('MockERC20 deployed to', mock.address);

  const Bridge = await ethers.getContractFactory('XANBridge');
  const bridge = await Bridge.deploy(mock.address);
  await bridge.deployed();
  console.log('XANBridge deployed to', bridge.address);

  const tx = await mock.transfer(bridge.address, ethers.utils.parseUnits('10000', 18));
  await tx.wait();
  console.log('Seeded bridge with 10000 XAN');
}

main().catch((error) => {
  console.error(error);
  process.exitCode = 1;
});