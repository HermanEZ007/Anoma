require('dotenv').config();
require('@nomiclabs/hardhat-waffle');

module.exports = {
  solidity: {
    compilers: [
      { version: '0.8.17' },
    ],
  },
  networks: {
    hardhat: {},
    localhost: {
      url: 'http://127.0.0.1:8545'
    }
  }
};