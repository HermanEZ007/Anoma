const { ethers } = require('hardhat');

function parseUnits(amount, decimals=18) {
  return ethers.utils.parseUnits(amount.toString(), decimals);
}

module.exports = { parseUnits };