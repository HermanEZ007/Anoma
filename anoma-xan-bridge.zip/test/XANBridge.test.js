const { expect } = require('chai');
const { ethers } = require('hardhat');

describe('XANBridge', function () {
  let Mock, mock, Bridge, bridge, owner, relayer, user;

  beforeEach(async function () {
    [owner, relayer, user] = await ethers.getSigners();

    Mock = await ethers.getContractFactory('MockERC20');
    mock = await Mock.deploy('Mock XAN', 'XAN', ethers.utils.parseUnits('1000000', 18));
    await mock.deployed();

    Bridge = await ethers.getContractFactory('XANBridge');
    bridge = await Bridge.deploy(mock.address);
    await bridge.deployed();

    await mock.transfer(bridge.address, ethers.utils.parseUnits('10000', 18));
  });

  it('user can lock tokens and emit Locked', async function () {
    const amount = ethers.utils.parseUnits('100', 18);
    await mock.connect(user).faucet(user.address, amount);
    await mock.connect(user).approve(bridge.address, amount);

    const tx = await bridge.connect(user).lock(amount, ethers.utils.toUtf8Bytes('anoma:alice'));
    const receipt = await tx.wait();
    const ev = receipt.events.find(e => e.event === 'Locked');
    expect(ev).to.not.be.undefined;
    expect(ev.args[1]).to.equal(amount);
  });

  it('only relayer can release', async function () {
    const amount = ethers.utils.parseUnits('50', 18);
    await expect(bridge.connect(user).release(user.address, amount, ethers.utils.toUtf8Bytes('id'), ethers.constants.HashZero)).to.be.revertedWith('only relayer');
  });

  it('relayer can release and processed prevents double spend', async function () {
    await bridge.connect(owner).setRelayer(relayer.address);
    const amount = ethers.utils.parseUnits('50', 18);
    const proofId = ethers.utils.keccak256(ethers.utils.toUtf8Bytes('proof1'));
    await expect(bridge.connect(relayer).release(user.address, amount, ethers.utils.toUtf8Bytes('id'), proofId)).to.emit(bridge, 'Released');
    await expect(bridge.connect(relayer).release(user.address, amount, ethers.utils.toUtf8Bytes('id'), proofId)).to.be.revertedWith('already processed');
  });
});