# anoma-xan-bridge

Hardhat starter project for a simple EVM-side XAN bridge.

## Quickstart
1. Install: `npm install`
2. Compile: `npm run compile`
3. Run tests: `npm test`
4. Deploy locally: `npm run deploy` (requires local node)
